from scripts.train import train_and_evaluate

if __name__ == "__main__":
    train_and_evaluate()
